const data = JSON.parse(localStorage.getItem("assessmentResult"));

if (!data) {
  document.getElementById("result-root").innerHTML =
    "<p>No assessment data found.</p>";
} else {
  renderResult(data);
}

function renderResult(data) {
  const root = document.getElementById("result-root");

  root.innerHTML = `
    <h1>Your Career Match</h1>

    <section>
      <h2>${data.bestCareer.name}</h2>
      <p>Match Score: ${(data.bestCareer.score * 100).toFixed(0)}%</p>
      <button id="roadmapBtn">View Roadmap</button>
    </section>

    <section>
      <h3>Your Trait Profile</h3>
      ${Object.entries(data.traits)
        .map(([trait, value]) => `
          <div>
            <label>${trait}</label>
            <progress value="${value * 100}" max="100"></progress>
            ${(value * 100).toFixed(0)}%
          </div>
        `).join("")}
    </section>
  `;

  document.getElementById("roadmapBtn").onclick = () => {
    localStorage.setItem("selectedCareerId", data.bestCareer.id);
    window.location.href = "CareerRoadmapPage.html";
  };
}
